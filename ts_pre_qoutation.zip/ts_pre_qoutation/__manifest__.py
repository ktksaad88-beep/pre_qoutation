# -*- coding: utf-8 -*-
{
    'name': "ts_pre_qoutation",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "teamUp4solutions, TaxDotCom",
    # 'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'ts_eval_sheet', 'quotation_custom_layout', 'ts_cost_analysis', 'base_import'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/addons_views.xml',
        # 'views/pre_sale_menus.xml',
        'report/sample_report_xls.xml',
    ],
    'license': 'OPL-1',
    'installable': True,
}
