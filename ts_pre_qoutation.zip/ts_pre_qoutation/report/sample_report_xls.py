from odoo import api, models


class AuditXlsReport(models.AbstractModel):
    _name = 'report.ts_pre_qoutation.sample_report_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def format_date(self, date_obj):
        return date_obj.strftime("%d %b, %Y")

    @api.model
    def generate_xlsx_report(self, workbook, data, records):
        sheet = workbook.add_worksheet()

        # FORMATS
        header_format = workbook.add_format(
            {'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_size': 12, 'border': 1})

        # Write column headers
        headers = ['Display Type', 'Model/Part', 'Description', 'Qty', 'UoM', 'Unit Price', 'Margin Rate',
                   'Cost Per Unit', 'Brand', 'Service', 'Discount', 'Optional']
        spacing = 4
        for col, header in enumerate(headers):
            sheet.set_column(col, col, (len(header) + spacing))
            sheet.write(0, col, header, header_format)

        # Return the workbook
        return workbook
