from odoo import models, fields


class CompanyExtended(models.Model):
    _inherit = 'res.company'

    use_pre_quotation = fields.Boolean("Use Pre-Quotation", default=False)
