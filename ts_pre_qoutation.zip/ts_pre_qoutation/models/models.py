# -*- coding: utf-8 -*-

import binascii
import logging
import tempfile

import xlrd
from odoo.exceptions import UserError

from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class SaleOrderInherited(models.Model):
    _inherit = 'sale.order'

    state = fields.Selection(selection_add=[('pre', 'Prepare'), ('draft',)], default='draft')

    order_lines_file = fields.Binary(string='Order Lines File',
                                     help='xlsx file containing order lines in specific format')
    order_lines_file_name = fields.Char(string='File Name')
    use_pre_quotation = fields.Boolean(related='company_id.use_pre_quotation')

    @api.model
    def default_get(self, fields):
        res = super(SaleOrderInherited, self).default_get(fields)
        company_id = self.company_id or self.env.company
        if company_id.use_pre_quotation:
            res['state'] = 'pre'
        return res

    def map_header(self, header_list):
        mapping_dict = {
            'Display Type': 'display_type',
            'Model/Part': 'temp_product_id',
            'Description': 'name',
            'Qty': 'temp_product_uom_qty',
            'UoM': 'temp_product_uom',
            'Unit Price': 'temp_price_unit',
            'Margin Rate': 'ts_margin_rate',
            'Cost Per Unit': 'ts_cost_per_unit',
            'Brand': 'ts_brand_1',
            'Service': 'ts_services',
            'Discount': 'discount',
            'Optional': 'is_optional',
        }
        return [mapping_dict.get(header, header) for header in header_list]

    def process_uploaded_file(self):
        self.ensure_one()
        # Get the binary data from the uploaded file
        fp = tempfile.NamedTemporaryFile(suffix=".xlsx")
        fp.write(binascii.a2b_base64(self.order_lines_file))
        fp.seek(0)
        book = xlrd.open_workbook(fp.name)
        sheets = book.sheet_names()
        sheet = sheets[0]
        records_data = self.env['base_import.import']._read_xls_book(book, sheet)
        records_data = records_data[1]
        # first check if it is adaptable or not
        records_data[0] = self.map_header(records_data[0])
        # Convert data into the format expected by Odoo (6, 0, records)
        sale_order_line_model = self.env['sale.order.line']

        field_info = {}
        optional = 'is_optional'
        for field in records_data[0]:
            if field == optional:
                field_info[field] = {'type': 'bool', 'comodel_name': '', }
                continue
            item = sale_order_line_model._fields[field]
            field_info[field] = {'type': item.type, 'comodel_name': item.comodel_name, }
            if item.type == 'selection':
                field_info[field]['selection'] = item.selection
        records = []
        for data in records_data[1:]:  # Skip the header
            record_vals = {}
            for field, value in zip(records_data[0], data):
                field_data = field_info.get(field, False)
                field_type = field_data.get('type', 'char')
                if field_type in ['integer', 'float', 'monetary']:
                    try:
                        record_vals[field] = int(value) if field_type == 'integer' else float(value)
                    except ValueError:
                        record_vals[field] = value  # If casting fails, keep the original value
                elif field_type == 'selection':
                    try:
                        field_selection = field_info.get(field, {}).get('selection', {})
                        for sel_key, key_string in field_selection:
                            if key_string == value:
                                record_vals[field] = sel_key
                                break
                    except ValueError:
                        record_vals[field] = value  # If casting fails, keep the original value
                elif field_type == 'many2one':
                    try:
                        model_name = field_data.get("comodel_name", '')
                        rec_id = self.env[str(model_name)].search([('name', '=', value)], limit=1)
                        # todo needs to be looked into
                        if not rec_id and value:
                            print(f"new record as its not in DB model:{model_name} and val {value}")
                            rec_id = self.env[str(model_name)].create({'name': value})
                        record_vals[field] = rec_id.id
                    except ValueError:
                        record_vals[field] = None  # If casting fails, set None value
                else:
                    record_vals[field] = value  # Keep the original value for non-numeric fields
            # validate vals according to type of field
            records.append(record_vals)
        # Update the order_line field with the new records
        new_records = []
        opt_records = []
        for values_dict in records:
            # Add order_id to the context
            values_dict['order_id'] = self.id
            if values_dict.get(optional, False):
                values_dict.pop(optional, None)
                opt_records.append(values_dict)
            else:
                values_dict.pop(optional, None)
                new_records.append(values_dict)
        line_model = self.env['sale.order.line']
        self.order_line.unlink()
        try:
            for vals_dict in new_records:
                print(vals_dict)
                vals_dict = line_model.validate_order_line_vals(vals_dict)
                line_model.create(vals_dict)
                _logger.info(f"New records created successfully. from vals:{vals_dict}")
        except Exception as e:
            _logger.error("Error occurred while creating new records: %s", str(e))

        # now adding optional products
        self.sale_order_option_ids.unlink()
        option_model = self.env['sale.order.option']
        opt_mapping_dict = {
            'name': 'name',
            'discount': 'discount',
            'order_id': 'order_id',
            'temp_product_id': 'temp_product_id',
            'temp_product_uom': 'temp_product_uom',
            'temp_product_uom_qty': 'quantity',
            'temp_price_unit': 'price_unit'
        }
        for vals_dict in opt_records:
            vals_dict = option_model.remove_unmatched_pairs(opt_mapping_dict, vals_dict)
            vals_dict = option_model.convert_keys(opt_mapping_dict, vals_dict)

            val = vals_dict['temp_product_uom']
            uom = option_model.get_uom(val)
            vals_dict['temp_product_uom'] = uom.name or val
            option_model.create(vals_dict)

    @api.depends('order_line.tax_id', 'order_line.price_unit', 'order_line.temp_price_unit', 'amount_total',
                 'amount_untaxed', 'currency_id')
    def _compute_tax_totals(self):
        for order in self:
            order_lines = order.order_line.filtered(lambda x: x.display_type in ['pre', False])
            order.tax_totals = self.env['account.tax']._prepare_tax_totals(
                [x._convert_to_tax_base_line_dict() for x in order_lines],
                order.currency_id or order.company_id.currency_id,
            )

    def action_preparation_confirm(self):
        if self.filtered(lambda so: so.state != 'pre'):
            raise UserError(_("Only Pre orders can be marked as Quotations."))
        # TODO handle the the conversion from pre to draft along its operation
        self.write({'state': 'draft'})
        line_model = self.env['sale.order.line']
        for rec in self:
            new_lines = []
            for line in rec.order_line:
                if line.display_type == "pre":
                    new_line = line.transform_sale_order_line_data(line.get_line_dict())
                    new_lines.append(new_line)
                else:
                    line_dict = line.read()[0]
                    for key, value in line_dict.items():
                        if isinstance(value, tuple):
                            line_dict[key] = value[0]
                    line_dict['id'] = False
                    new_lines.append(line_dict)

            rec.order_line.unlink()

            for vals_dict in new_lines:
                print(vals_dict)
                line_model.create(vals_dict)

            # === shifting optional lines ===
            new_lines = []
            for line in rec.sale_order_option_ids:
                line_dict = line.get_optional_dict()
                new_line = line.transform_sale_order_optional_data(line_dict)
                new_lines.append(new_line)
            rec.sale_order_option_ids.unlink()
            option_model = self.env['sale.order.option']
            for vals_dict in new_lines:
                option_model.create(vals_dict)

    def action_reset_to_pre(self):
        """
        Reset the sale order to a 'pre' state by reversing the changes made in the
        'action_preparation_confirm' method.
        """
        line_model = self.env['sale.order.line']

        try:
            for order in self:
                lines = []
                for line in order.order_line:
                    if not line.display_type:
                        update_vals = {
                            'order_id': line.order_id.id,
                            'display_type': 'pre',
                            'product_id': False,
                            'price_unit': 0.0,
                            'product_uom_qty': 0.0,
                            'product_uom': False,
                            'temp_product_id': line.product_id.name.strip() if line.product_id else False,
                            'temp_price_unit': line.price_unit,
                            'temp_product_uom_qty': line.product_uom_qty,
                            'temp_product_uom': line.product_uom.id,
                            'name': line.name.strip(),
                            'ts_margin_rate': line.ts_margin_rate,
                            'ts_cost_per_unit': line.ts_cost_per_unit,
                            'is_lumpson': line.is_lumpson,
                            'discount': line.discount,
                            'tax_id': line.tax_id.ids,
                            'ts_brand_1': line.ts_brand_1.id if line.ts_brand_1 else False,
                            'ts_services': line.ts_services.id if line.ts_services else False,
                            'ts_supplier': line.ts_supplier.id,
                            'customer_lead': line.customer_lead,
                        }
                        lines.append(update_vals)
                    else:
                        line_dict = line.read()[0]
                        for key, value in line_dict.items():
                            if isinstance(value, tuple):
                                line_dict[key] = value[0]
                        line_dict['id'] = False
                        lines.append(line_dict)

                order.order_line.unlink()

                order.write({'state': 'pre'})
                for vals_dict in lines:
                    line_model.create(vals_dict)
                #   Resetting optional lines
                for line in order.sale_order_option_ids:
                    line.reset_optional_lines()

        except Exception as e:
            raise UserError(_("On action_reset_to_pre():An error occurred: %s" % e))


class PreSaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    # Fields specifying custom line logic
    display_type = fields.Selection(selection_add=[('pre', "Prepare")])

    temp_product_id = fields.Char(string="Model/Part")
    temp_price_unit = fields.Float(string="Unit Price")

    temp_product_uom_qty = fields.Float(
        string="Qty",
        digits='Product Unit of Measure', default=0.0,
        store=True, readonly=False, required=True)
    temp_product_uom = fields.Many2one(
        comodel_name='uom.uom',
        string="UoM",
        store=True, readonly=False)

    @api.model
    def get_fields_by_prop(self, property=None):
        model_fields = self.fields_get()
        return {
            name: field_info
            for name, field_info in model_fields.items()
            if field_info.get(property)
        }

    def transform_sale_order_line_data(self, record):
        # Mapping of temp fields to original fields
        field_mapping = {
            'temp_product_id': 'product_id',
            'temp_price_unit': 'price_unit',
            'temp_product_uom_qty': 'product_uom_qty',
            'temp_product_uom': 'product_uom',
        }

        # Loop through all keys and check if the value is a tuple, then extract the first element
        for key, value in record.items():
            if isinstance(value, tuple):
                record[key] = value[0]

        # Shift data from temp fields to original fields
        for temp_field, original_field in field_mapping.items():
            val = record.get(temp_field, record.get(original_field))
            if temp_field == 'temp_product_id':
                # Check if the product already exists or create a new one
                product_id = 0  # Set to 0 for a new record
                if val:
                    # Find or create the product
                    product_id = self.env['product.product'].search([('name', '=', val)], limit=1).id
                    if not product_id:
                        product_id = self.env['product.product'].create({'name': val}).id
                record[original_field] = product_id
                # [(0, 0, {"name": val, 'detailed_type': 'product'})]
            else:
                record[original_field] = val

        # Remove temp fields from the dictionary
        record = {key: value for key, value in record.items() if
                  key not in field_mapping and key not in ['display_type', 'id']}

        return record

    def transform_line_data_to_pre_state(self, record):
        # Mapping of temp fields to original fields
        field_mapping = {
            'product_id': 'temp_product_id',
            'price_unit': 'temp_price_unit',
            'product_uom_qty': 'temp_product_uom_qty',
            'product_uom': 'temp_product_uom',
        }

        # Loop through all keys and check if the value is a tuple, then extract the first element
        for key, value in record.items():
            if isinstance(value, tuple):
                record[key] = value[0]

        # Shift data from temp fields to original fields
        for temp_field, original_field in field_mapping.items():
            val = record.get(temp_field, record.get(original_field))
            record[original_field] = val

        # Remove temp fields from the dictionary
        record = {key: value for key, value in record.items() if
                  key not in field_mapping and key not in ['display_type', 'id']}

        return record

    def get_line_dict(self):
        self.ensure_one()
        line_dict = self.read(fields=[
            'display_type',
            'order_id',
            'product_id',
            'temp_product_id',
            'name',
            'price_unit',
            'temp_price_unit',
            'product_uom',
            'temp_product_uom',
            'product_uom_qty',
            'temp_product_uom_qty',
            'ts_margin_rate',
            'ts_cost_per_unit',
            'ts_brand',
            'ts_brand_1',
            'ts_services',
        ])
        return line_dict[0]

    def _convert_to_tax_base_line_dict(self):
        """ Convert the current record to a dictionary in order to use the generic taxes computation method
        defined on account.tax.

        :return: A python dictionary.
        """
        self.ensure_one()
        price_unit = self.price_unit
        quantity = self.product_uom_qty
        if self.state == 'pre':
            price_unit = self.temp_price_unit
            quantity = self.temp_product_uom_qty
        res = self.env['account.tax']._convert_to_tax_base_line_dict(
            self,
            partner=self.order_id.partner_id,
            currency=self.order_id.currency_id,
            product=self.product_id,
            taxes=self.tax_id,
            price_unit=price_unit,
            quantity=quantity,
            discount=self.discount,
            price_subtotal=self.price_subtotal,
        )
        return res

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id', 'temp_price_unit', 'temp_product_uom_qty')
    def _compute_amount(self):
        super(PreSaleOrderLine, self)._compute_amount()

    @api.depends('ts_margin_rate', 'ts_cost_per_unit')
    def _compute_ts_total_cost(self):
        for line in self:
            if line.state == 'pre':
                line.temp_price_unit = line.ts_margin_rate * line.ts_cost_per_unit
                line.ts_total_cost = line.temp_product_uom_qty * line.ts_cost_per_unit
            else:
                line.price_unit = line.ts_margin_rate * line.ts_cost_per_unit
                line.ts_total_cost = line.product_uom_qty * line.ts_cost_per_unit
            line.ts_margin_price_and_cost = line.price_subtotal - line.ts_total_cost

    @api.model
    def validate_order_line_vals(self, vals_dict):
        display_type = vals_dict.get('display_type', '')
        if display_type in ['line_section', 'line_note']:
            vals_dict['temp_product_id'] = None
            vals_dict['temp_price_unit'] = None
            vals_dict['ts_margin_rate'] = None
            vals_dict['ts_cost_per_unit'] = None
            vals_dict['ts_brand_1'] = None
            vals_dict['ts_services'] = None
            vals_dict['product_uom_qty'] = None
            vals_dict['temp_product_uom'] = None
            vals_dict['temp_product_uom_qty'] = None
        return vals_dict
