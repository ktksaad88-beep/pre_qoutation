# -*- coding: utf-8 -*-

from odoo.exceptions import ValidationError

from odoo import models, fields, api


class PreSaleOrderOption(models.Model):
    _inherit = 'sale.order.option'

    temp_product_id = fields.Char("Product")
    temp_product_uom = fields.Char("UoM")

    product_id = fields.Many2one(required=False)
    uom_id = fields.Many2one(required=False)

    def _check_required_fields(self, vals, write=False):
        rec = self.new(vals)
        if rec.order_id.state != 'pre' and all(field not in vals for field in ['product_id', 'uom_id']):
            raise ValidationError("One or more required fields are missing.")
        del rec

    @api.model
    def create(self, vals):

        self._check_required_fields(vals)
        return super(PreSaleOrderOption, self).create(vals)

    def write(self, vals):

        # self._check_required_fields(vals)
        return super(PreSaleOrderOption, self).write(vals)

    @api.model
    def convert_keys(self, mapping_dict, source_dict):
        """
        Convert keys in the source dictionary based on the mapping dictionary.

        Parameters:
        - mapping_dict (dict): A dictionary containing the mapping of old keys to new keys.
        - source_dict (dict): The source dictionary to be modified.

        Returns:
        - dict: The modified source dictionary with keys converted based on the mapping.
        """
        converted_dict = source_dict.copy()

        for old_key, new_key in mapping_dict.items():
            if old_key in converted_dict:
                converted_dict[new_key] = converted_dict.pop(old_key)
        return converted_dict

    @api.model
    def remove_unmatched_pairs(self, mapping_dict, source_dict):
        source_dict_keys = set(source_dict.keys())
        mapping_dict_keys = set(mapping_dict.keys())
        unmatched_keys = source_dict_keys - mapping_dict_keys

        for key in unmatched_keys:
            if key in source_dict:
                del source_dict[key]
        return source_dict

    def get_optional_dict(self):
        self.ensure_one()

        line_dict = self.read(fields=[
            'name',
            'discount',
            'order_id',
            'temp_product_id',
            'temp_product_uom',
            'quantity',
            'price_unit'
        ])
        return line_dict[0]

    @api.model
    def get_uom(self, val):
        # self.ensure_one()
        search_domain = [('name', '=', val)] if not isinstance(val, int) else [('id', '=', val)]
        uom_id = self.env['uom.uom'].search(search_domain, limit=1)
        if not uom_id:
            return False
        return uom_id

    def transform_sale_order_optional_data(self, record, file_processing=False):
        # Mapping of temp fields to original fields

        field_mapping = {
            'temp_product_id': 'product_id',
            'temp_product_uom_qty': 'quantity',
            'temp_product_uom': 'uom_id',
        }

        # Loop through all keys and check if the value is a tuple, then extract the first element
        for key, value in record.items():
            if isinstance(value, tuple):
                record[key] = value[0]

        # Shift data from temp fields to original fields
        for temp_field, original_field in field_mapping.items():
            val = record.get(temp_field, record.get(original_field))
            if temp_field == 'temp_product_id':
                # Check if the product already exists or create a new one
                product_id = 0  # Set to 0 for a new record
                if val:
                    # Find or create the product
                    product_id = self.env['product.product'].search([('name', '=', val)], limit=1).id
                    if not product_id:
                        product_id = self.env['product.product'].create({'name': val}).id
                record[original_field] = product_id
                # [(0, 0, {"name": val, 'detailed_type': 'product'})]
            elif temp_field == 'temp_product_uom':
                uom_id = self.get_uom(val)
                if not uom_id:
                    raise ValidationError("UoM field has invalid data or missing.")
                record[original_field] = uom_id.id
            else:
                record[original_field] = val

        # Remove temp fields from the dictionary
        record = {key: value for key, value in record.items() if
                  key not in field_mapping and key not in ['display_type', 'id']}

        return record

    def reset_optional_lines(self):
        self.ensure_one()
        update_vals = {
            'product_id': False,
            'uom_id': False,
            'temp_product_id': self.product_id.name.strip() if self.product_id else False,
            'temp_product_uom': self.uom_id.name,
        }
        self.update(update_vals)
