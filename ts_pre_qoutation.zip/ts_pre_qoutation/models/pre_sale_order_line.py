# -*- coding: utf-8 -*-

from odoo import models, fields, api


class PreSaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    # Fields specifying custom line logic
    display_type = fields.Selection(selection_add=[('pre', "Prepare")])

